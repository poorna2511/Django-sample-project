from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request, 'calc_home.html', {'name':'Poorna', 'buttonName':'this button is special'})

def Add(request):
    val2 = request.POST['num2']
    val1 = request.POST['num1']

    val3 = val1 + val2
    return render(request, 'calc_result.html', {"AdditonResult" : val3})