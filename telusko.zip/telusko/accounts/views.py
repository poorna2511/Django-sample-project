from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

def logout(request):
    auth.logout(request)
    return redirect('/')

def login(request):
    if request.method == 'POST':
        iUsername = request.POST['username']
        iPassword = request.POST['password']

        iUser = auth.authenticate(username = iUsername, password = iPassword)

        if iUser is not None:
            auth.login(request, iUser)
            return redirect('/')
        else:
            messages.info(request, 'wrong username or password')
            return redirect('login')
    else:
        return render(request, 'login.html')

# Create your views here.
def register(request):

    if request.method == 'POST':
        iFirstName = request.POST['first_name']
        iLastName = request.POST['last_name']
        iUsername = request.POST['username']
        iEmail = request.POST['email']
        iPassword1 = request.POST['password1']
        iPassword2 = request.POST['password2']

        print(iPassword1)
        print(iPassword2)

        if iPassword1 == iPassword2:
            if User.objects.filter(username = iUsername).exists():
                messages.info(request, 'user already exists')
            elif User.objects.filter(email = iEmail).exists():
                messages.info(request, 'email already exists')
            else:
                iUser = User.objects.create_user(first_name = iFirstName, last_name = iLastName, username = iUsername, email = iEmail, password = iPassword1)
                iUser.save()
                messages.info(request, 'user created')
                return redirect('login')
        else:
            messages.info(request, 'password not match')

    return render(request, 'register.html')
    