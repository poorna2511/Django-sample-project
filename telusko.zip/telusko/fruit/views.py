from django.shortcuts import render
from .models import Fruit

# Create your views here.
def home(request):

    ## this code is written to add fruits list manually and send it to html
    ## no data base usage is done here

    # fruit1 = Fruit()
    # fruit1.name = 'Apple'
    # fruit1.price = 10
    # fruit1.rating = '9/10'
    # fruit1.img = 'apple.jpg'
    # fruit1.offer = False

    # fruit2 = Fruit()
    # fruit2.name = 'Banana'
    # fruit2.price = 12
    # fruit2.rating = '7/10'
    # fruit2.img = 'banana.jpg'
    # fruit2.offer = True

    # fruit3 = Fruit()
    # fruit3.name = 'Watermelon'
    # fruit3.price = 15
    # fruit3.rating = '8/10'
    # fruit3.img = 'watermelon.jpg'
    # fruit3.offer = False

    # allfruits = [fruit1, fruit2, fruit3]
    
    ## this is getting list of fruits data from data base and passing it to html
    ## this data can be added by the admin using django admin panel
    allfruits = Fruit.objects.all()

    return render(request, 'index.html', {'objs' : allfruits})
