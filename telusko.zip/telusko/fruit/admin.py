from django.contrib import admin
from .models import Fruit

# Register your models here.
admin.site.register(Fruit)
